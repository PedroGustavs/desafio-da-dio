let nome;
let quantidade_xp;
let nivel;

nome = prompt("Por favor, informe o seu nome:");

do{
    quantidade_xp = parseInt(prompt("Por favor, informe a sua quantidade de experiencia:"));
    
    if(quantidade_xp < 0){
        console.log("Quantidade invalida");
    }
    
} while(quantidade_xp < 0);

if(quantidade_xp < 1000){
    nivel = "Ferro";
}
else if(quantidade_xp >= 1001 && quantidade_xp <= 2000){
    nivel = "Bronze";
}
else if(quantidade_xp >= 2001 && quantidade_xp <= 5000){
    nivel = "Prata";
}
else if(quantidade_xp >= 5001 && quantidade_xp <= 7000){
    nivel = "Ouro";
}
else if(quantidade_xp >= 7001 && quantidade_xp <= 8000){
    nivel = "Platina";
}
else if(quantidade_xp >= 8001 && quantidade_xp <= 9000){
    nivel = "Ascendente";
}
else if(quantidade_xp >= 9001 && quantidade_xp <= 10000){
    nivel = "Imortal";
}
else{
    nivel = "Radiante";
}

console.log(`O Herói de nome ${nome} está no nível de ${nivel}`);

